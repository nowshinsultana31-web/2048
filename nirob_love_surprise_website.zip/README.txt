NIROB — A LITTLE PIECE OF US
=============================

FILES
- index.html: complete responsive website; no build tools required.

PREVIEW
1. Extract the ZIP.
2. Open index.html in a browser. On a phone, you can open it from a file manager,
   though uploading it to a host is better for sharing.
3. Tap “Play soft music” to start the gentle original synthesized background tones.
   Browsers do not allow audio autoplay until the visitor taps.

PERSONALIZE BEFORE SHARING
- Open index.html in a text editor.
- Search for SECRET_PASSWORD = "nirobjaan" and change the password.
- Search for “Replace this with your real first memory”, “Add an inside joke here”,
  and “Add a favourite plan or dream” to customize the memory cards.
- Edit the love letter and final surprise so they sound like you.
- For real privacy: the password is a front-end reveal only. Anyone who inspects
  the source code can see it; do not use this for private/confidential content.

PUBLISH FREE WITH GITHUB PAGES
1. Sign in or create an account at https://github.com/
2. Create a new public repository, e.g. nirob-surprise.
3. Upload index.html to the repository's top level (not inside another folder).
4. Open Settings → Pages.
5. Under Build and deployment, choose “Deploy from a branch”.
6. Choose branch “main” and folder “/(root)”, then Save.
7. Wait for deployment. The Pages screen will show the website URL, usually
   https://YOUR-USERNAME.github.io/nirob-surprise/
8. Open that URL on your phone to test it, then send it to Nirob.

Alternative: Netlify Drop
- Visit https://app.netlify.com/drop and drop the extracted project folder
  (or a ZIP if the page accepts it). Follow the prompts to publish and get a URL.

NOTE
- This is a static site and requires no server or installation.
- Background sound is generated in the browser using Web Audio; no song file is included.
- The password is for surprise/reveal fun, not real security.
